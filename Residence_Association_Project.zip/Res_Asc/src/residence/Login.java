package residence;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class LoginFrame extends JFrame implements ActionListener 
{//using Jframe class members for designing the Login page for the admin alone
    Container contain = getContentPane();
    JLabel userLabel = new JLabel("USERNAME");
    JLabel passwordLabel = new JLabel("PASSWORD");
    JTextField userTextField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JButton loginButton = new JButton("LOGIN");
    JButton resetButton = new JButton("RESET");
    JCheckBox showPassword = new JCheckBox("Show Password");
    LoginFrame() 
    {//default constructor
        setLayoutManager();
        setLocationAndSize();
        addComponents();
        addActionEvent();
    }
    public void setLayoutManager() 
    {//to set the layout
        contain.setLayout(null);
    }
    public void setLocationAndSize() 
    {// to set the location and size of each field
        userLabel.setBounds(50, 150, 100, 30);
        passwordLabel.setBounds(50, 220, 100, 30);
        userTextField.setBounds(150, 150, 150, 30);
        passwordField.setBounds(150, 220, 150, 30);
        showPassword.setBounds(150, 250, 150, 30);
        loginButton.setBounds(50, 300, 100, 30);
        resetButton.setBounds(200, 300, 100, 30);
    }
    public void addComponents() 
    {//adding the labels and buttons
        contain.add(userLabel);
        contain.add(passwordLabel);
        contain.add(userTextField);
        contain.add(passwordField);
        contain.add(showPassword);
        contain.add(loginButton);
        contain.add(resetButton);
    }
    public void addActionEvent() 
    {
        loginButton.addActionListener(this);
        resetButton.addActionListener(this);
        showPassword.addActionListener(this);
    }
    public void actionPerformed(ActionEvent a) 
    {
    	Manager obj1 = new Manager();
    	Welcome obj2 = new Welcome();
        if (a.getSource() == loginButton) 
        {
            String userText;
            String pwdText;
            userText = userTextField.getText();
            pwdText = passwordField.getText();
        	synchronized(this)
            {
            try {
            if (userText.equalsIgnoreCase("Sai Dhanush") && pwdText.equalsIgnoreCase("sid1389")) {
                JOptionPane.showMessageDialog(this, "Login Successful");
                obj1.admin();   
            }
            else 
            {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password");
            }
            }
            catch(Exception ex)
            {
            	System.out.println(ex);
            }
            }
        }
        if (a.getSource() == resetButton) 
        {
            userTextField.setText("");
            passwordField.setText("");
        }
        if (a.getSource() == showPassword) 
        {
            if (showPassword.isSelected())
                passwordField.setEchoChar((char) 0);
            else 
                passwordField.setEchoChar('#');
        }
    }
    public void windowClosing(WindowEvent w) 
    {
        dispose();
    }
}
public class Login extends Thread
{
    void perform() 
    {//called by menu()
        LoginFrame frame = new LoginFrame();
        frame.setTitle("Admin page validation");
        frame.setVisible(true);
        frame.setBounds(10, 10, 370, 400);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
    }
}