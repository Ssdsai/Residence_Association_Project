package residence;
import java.util.*;
import java.lang.*;
public class Welcome
{//Declaration of instance and static variables
	int fl_no,a,flat_no[],area[],fl_num;
	public static int ct=0;
	long fl_ph;
	public static long manager=0,security=0,maid_inch=0,swim=0,gym=0,lift=0,garden=0;
	char pos;
	public static double m_sum = 0.0,f_sum=0.0;
	public static final double cost[]= {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
	String fl_ow,pass;
	public static String passo,passr,passl;
	Welcome()
	{//Default constructor  
		Welcome.passo = "1234O";
		Welcome.passr = "5678R";
		Welcome.passl = "9012L";
		flat_no = new int[]{101,102,103,104,105,106,107,108,109,110};//available flats in the whole apartment 
		area = new int[]{1230,1450,1500,1200,1700,1290,1300,1450,1610,1250};//area of each flat in sq ft
	}
	Welcome(String npo,char p)
	{//Parameterized constructor
		if(p=='O')
			Welcome.passo=npo;
		else if(p=='R')
			Welcome.passr=npo;
		else
			Welcome.passl=npo;
	}
	public static void main(String[] args) throws Exception 
	{
		Welcome obj = new Welcome();
		obj.menu();//calls the menu section
	}
	public void menu() throws Exception
	{
		int choice=0,ch=1;
		for(int i=0;i<10;i++) 
		{
			Welcome.cost[i] = area[i]*1.75;
			Welcome.m_sum+=Welcome.cost[i];
		}//computing the maintenance cost and saving it
		setContact();//setter function to set the contact numbers
		Welcome.f_sum = flat_no.length*8000;
		Scanner sc = new Scanner(System.in);
		Login obj1 = new Login();
		LoginRegisterPage obj2 = new LoginRegisterPage();
		TreasuryPage obj3 = new TreasuryPage();
		ComplaintPage obj4 = new ComplaintPage();
		Manager obj5 = new Manager();
		System.out.println("\tThe Resi_Aso is located in XXX place. It comes under A survey.");
		System.out.println("\tThe area of the apartment is 5 acres. It has south facing gate.");
		System.out.println("\tIt has gym .\n\n");
		do
		{
		System.out.println("\n\t\tMENU\n\t\t-----\n");
		System.out.println("\t1.Admin page\n\t2.Welcome\n\t3.Treasury\n\t4.Help\n\t5.Exit\n"); 
		try
		{
			System.out.println("Please enter your choice (1-5) :-");
			choice = sc.nextInt();
		}
		catch(Exception e)
		{
			System.out.println("Exception "+e);
		}
		switch(choice)
		{
			case 1:obj1.perform();
			       System.out.println("\nValidating.... ... .");
				   break;
			case 2:obj2.welcome();
				   System.out.println("\nTo go back to menu, please enter 0 button.");
				   ch=sc.nextInt();
				   break;
			case 3:obj3.maintain();
				   System.out.println("\nTo go back to menu, please enter 0 button.");
			       ch=sc.nextInt();
				   break;
			case 4:obj4.issues();
				   System.out.println("\nTo go back to menu, please enter 0 button.");
		           ch=sc.nextInt();
				   break;
			case 5:System.exit(0);
			       break;
			default:System.out.println("\nInvalid choice\n");
				    //menu();
		}
		}while(ch==0);
	}
	public void setContact()
	{//setter function
		Welcome.manager = 9876543210L;
		Welcome.security = 9786352410L;
		Welcome.maid_inch = 1126745996L;
		Welcome.swim = 4576787989L;
		Welcome.gym = 8769012345L;
		Welcome.lift = 7789033452L;
		Welcome.garden = 5465678789L;
	}
}