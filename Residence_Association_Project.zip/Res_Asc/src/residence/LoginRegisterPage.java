package residence;
import java.util.Scanner;
public class LoginRegisterPage extends Welcome 
{
	LinkedList list = new LinkedList();//object of Linked List
	Node ptr = new Node();//object of each Node
	public void welcome() throws Exception//Exception handling
	{
		int ch;
		Scanner sc = new Scanner(System.in);
		Login1 obj1 = new Login1();
		Register obj2 = new Register();
		System.out.println("\nWelcome to the Register/Login Page");
		System.out.println("The new residents or people who havent registered are asked to register first.");
		System.out.println("After registering u can login directly or come back to the section and login");
		System.out.println("Kindly select the option to be performed");
		System.out.println("\n\t~~~~\n\tOPTIONS\n\t~~~~\n\t1.Register\n\t2.Login");
		System.out.println("\nEnter your choice 1 or 2 :");
		ch=sc.nextInt();
		if(ch==1)
			obj2.register();
		else if (ch==2)
			obj1.login();
		else
			System.out.println("Invalid choice!!!");
	}
	class Login1
	{//sub-class 1
	public void login() throws Exception
	{
		int choice=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("\nPlease select the category you belong to :");
		System.out.println("1.Flat owner\n2.Rentee\n3.Lease\n");
		System.out.println("Enter your choice (1-3):");
		choice = sc.nextInt();
		if(choice==1)
		{
			try {
			System.out.println("\nEnter your flat number :");
			fl_no = sc.nextInt();
			ptr = list.search(fl_no);//getting the whole node where the info was found
			pos = ptr.getData5();
			fl_ow = ptr.getData2();
			System.out.println("Enter the password :");
			pass = sc.next();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				welcome();
			}
			if(pos=='O') {
			if(pass.equals(passo))
			{
				System.out.println("\nDear "+fl_ow+" !!\nLogged in successfully!!!\n");
				for(int i=0;i<10;i++)
					if(fl_no == flat_no[i])
					{
						System.out.println("Your registered contact number is "+ptr.getData4());
						System.out.println("The total number of members staying in your house are "+ptr.getData3());
						System.out.println("The area of your flat is "+area[i]+" sq ft");
						System.out.println("The cost of maintainence for your flat is Rs."+cost[i]+"/- per month");
						System.out.println("\nThe amount can be paid directly to the manager or through bill desk option available in Treasury page");
					}
			}
			else
			{
				System.out.println("Wrong password\nPlease check again\n");
				login();
			}	
			}
			else {
				System.out.println("\nYou are not a flat owner");
				System.out.println("Please read carefully and enter ");
				login();
			}
		}
		else if(choice == 2)
		{
			try {
			System.out.println("\nEnter your flat number :");
			fl_no = sc.nextInt();
			ptr = list.search(fl_no);//getting the whole node where the info was found
			fl_ow = ptr.getData2();
			System.out.println("Enter the password :");
			pass = sc.next();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				welcome();
			}
			if(pos=='R') {
			if(pass.equals(passr))
			{
				System.out.println("\nDear "+fl_ow+" !!\nLogged in successfully!!!\n");
				for(int i=0;i<10;i++)
					if(fl_no == flat_no[i])
					{
						System.out.println("Your registered contact number is "+ptr.getData4());
						System.out.println("The total number of members staying in your house are "+ptr.getData3());
						System.out.println("The area of your flat is "+area[i]+" sq ft");
						System.out.println("The cost of maintainence for your flat is Rs."+cost[i]+"/- per month");
						System.out.println("\nThe amount can be paid directly to the manager or through bill desk option available in Treasury page");
					}
			}
			else
			{
				System.out.println("Wrong password\nPlease check again\n");
				login();
			}
			}
			else {
				System.out.println("\nYou are not staying for rent");
				System.out.println("Please read carefully and enter ");
				login();
			}
		}
		else if(choice == 3)
		{
			try {
			System.out.println("\nEnter your flat number :");
			fl_no = sc.nextInt();
			ptr = list.search(fl_no);//getting the whole node where the info was found
			fl_ow = ptr.getData2();
			System.out.println("Enter the password :");
			pass = sc.next();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
				welcome();
			}
			if(pos=='L') {
			if(pass.equals(passl))
			{
				System.out.println("\nDear "+fl_ow+" !!\nLogged in successfully!!!\n");
				for(int i=0;i<10;i++)
					if(fl_no == flat_no[i])
					{
						System.out.println("Your registered contact number is "+ptr.getData4());
						System.out.println("The total number of members staying in your house are "+ptr.getData3());
						System.out.println("The area of your flat is "+area[i]+" sq.cm");
						System.out.println("The cost of maintainence for your flat is Rs."+Welcome.cost[i]+"/- per month");
						System.out.println("\nThe amount can be paid directly to the manager or through bill desk option available in Treasury page");
					}
			}
			else
			{
				System.out.println("Wrong password\nPlease check again\n");
				login();
			}
			}
			else {
				System.out.println("\nYou are not staying for lease");
				System.out.println("Please read carefully and enter ");
				login();
			}
		}
		else
			System.out.println("Wrong choice");
		}
	}
	class Register 
	{//sub-class 2
		public void register() throws Exception
		{
			Login1 obj1 = new Login1();
			Scanner sc = new Scanner(System.in);
			char ch;
			int flag = 0,num = 0;
			do
			{
			System.out.println("\nEnter your flat number : ");
			fl_no = sc.nextInt();
			for(int i=0;i<10;i++)
			if(fl_no == flat_no[i])
			{//searching in the declared flat array 
				flag=1;
				break;
			}
			if(flag==0)
			{
				System.out.println("\nThe flat doesn't exists");
				welcome();//Redirecting again to the welcome page
			}
			System.out.println("Enter your name :");
			fl_ow = sc.next();
			try 
			{
				System.out.println("Enter your contact number :");
				fl_ph = sc.nextInt();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			System.out.println("Enter the number of members staying :");
			fl_num = sc.nextInt();
			System.out.println("\nSelect one from the following?");
			System.out.println("1.Are you a owner\n2.Are you staying for rent\n3.Are you staying for lease\n");
			a=sc.nextInt();
			if(a==1)
			{
				pos = 'O';
				System.out.println("Your password for future login is "+passo);
			}
			else if(a==2)
			{
				pos = 'R';
				System.out.println("Your password for future login is "+passr);
			}
			else if(a==3)
			{
				pos = 'L';
				System.out.println("Your password for future login is "+passl);
			}
			else
				System.out.println("Wrong choice!!!\n");
			list.insertAtEnd(fl_no, fl_num,fl_ow,fl_ph,pos);//passing all the entered info into linked list
			System.out.println("Do u want to continue (y or n)?");
			ch=sc.next().charAt(0);
			}while(ch=='Y'||ch=='y');
			System.out.println("\nPress 1 to go back to Login page");
			num = sc.nextInt();
			if(num==1)
				obj1.login();
			else 
			{
				System.out.println("Wrong choice!!!\n");
				welcome();//for returning back to the same function
			}
		}	
	}
}