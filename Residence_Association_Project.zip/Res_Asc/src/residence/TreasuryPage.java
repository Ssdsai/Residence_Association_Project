package residence;
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.time.*;
public class TreasuryPage extends Welcome
{
	public void maintain() throws Exception
	{
		int choice=0,c=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("\nWelcome to the Finance related page of Resi_aso");
		System.out.println("Record of expenses and payment are maintained here");
		System.out.println("\n\t~~~~\n\tOPTIONS");
		System.out.println("\t~~~~");
		System.out.println("1.Account details\n2.Income and Expenditure\n3.Bill Desk");
		System.out.println("\nEnter your choice (1-3) :");
		choice = sc.nextInt();
		switch(choice)
		{
		case 1 : acc_det();
				 break;
		case 2 : expense();
				 break;
		case 3 : others();
				 break;
		default : System.out.println("\nInvalid choice!!!!\nPlease try again");
		}
		System.out.println("\nIf you want to go back to Treasury page please enter 1");
		c = sc.nextInt();
		if(c==1)
			maintain();//for returning back to the same function
	}
	void acc_det()
	{
		try {
		File b1 = new File("D:\\Eclipse\\Residence Association\\Banking.txt");
		BufferedReader br = new BufferedReader(new FileReader(b1));
        String file1;
        System.out.println("\nBanking details are :\n");
        while((file1 = br.readLine())!=null)
        System.out.println(file1);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	void expense() throws Exception
	{
		int size = 0;
		char buf1[] = new char[100];
		char buf2[] = new char[100];
		char buf3[] = new char[100];
		String div = null;
		double e_sum = 0.0,save = 0.0,i_sum=0.0;
		Scanner sc = new Scanner(System.in);
		LocalDate cd = LocalDate.now();
		System.out.println("\nRecord of income, expenditure and savings of the apartment\n\nSources of Income");
		try {
		FileReader b2 = new FileReader("D:\\Eclipse\\Residence Association\\Inc_nam.txt");
		b2.read(buf1);
		String data = String.valueOf(buf1);
		String arr[] = data.split("\n");
		for(String s:arr)
			System.out.println(s);
		System.out.println("Enter the division :");
		div = sc.nextLine();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		if (div.equalsIgnoreCase("Monthly_Maintanence"))
		{
			System.out.println("\nThe income through maintanence amount collected by all flats is Rs."+Welcome.m_sum+" per month\n");
		}
		else if(div.equalsIgnoreCase("Yearly_Fund"))
		{
			System.out.println("\nThe income through yearly fund collected every on random basis from each apartmrnt is Rs."+Welcome.f_sum+" per year\n");
		}
		else
			System.out.println("Wrong source of income");
		i_sum = Welcome.m_sum + Welcome.f_sum;
		System.out.println("Sources of expenditure :");
		try {
		FileReader b3 = new FileReader("D:\\Eclipse\\Residence Association\\Exp_nam.txt");
		b3.read(buf2);
		String data = String.valueOf(buf2);
		String arr[] = data.split("\n");
		size = arr.length;
		for(String s:arr)
			System.out.println(s);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		ArrayList<Double> exp_amt = new ArrayList<Double>();//Dynamic array list
		try {
		FileReader b4 = new FileReader("D:\\Eclipse\\Residence Association\\Exp_amt.txt");
		b4.read(buf3);
		String data = String.valueOf(buf3);
		String arr[] = data.split("\n");
		for(int i=0;i<size;i++)
		{
			exp_amt.add(Double.parseDouble(arr[i]));
			e_sum+=exp_amt.get(i);
		}
		System.out.println("\n");
		System.out.println(exp_amt);
		System.out.println("\n");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		System.out.println("The total expenditure is "+e_sum);
		save = i_sum - e_sum;
		if(save>0)
		{
			System.out.println("The savings for "+cd.getMonth()+" is Rs."+save);
			System.out.println("It can be credited to Bank account");
		}
		else if(save<0)
		{
			System.out.println("There has been more expenditure in "+cd.getMonth());
			System.out.println("The Extra amount(expenditure) is "+Math.abs(save));
			System.out.println("It should be debited from the Bank account");
		}
		else
		{
			System.out.println("The amount of income and expenditure has been same in "+cd.getMonth());
		}
	}
	void others()
	{
		double amt,pay,bal;
		int g_otp,e_otp,n=12345,c=0;
		char ch;
		LoginRegisterPage obj2 = new LoginRegisterPage();
		Scanner sc = new Scanner(System.in);
		System.out.println("\nWelcome for the payment section");
		System.out.println("Payment through bill desk");
		do {
		c++;
		System.out.println("\nEnter the amount to be paid -");
		amt = sc.nextDouble();
		System.out.println("The bill you have to pay is "+amt);
		g_otp=(int)(n*Math.random()+12*Math.random());
		System.out.println("The OTP generated for your future reference is "+g_otp);
		System.out.println("\nEnter the amount you are paying -");
		pay=sc.nextDouble();
		bal=amt-pay;
		System.out.println("Enter your OTP -");
		e_otp=sc.nextInt();
		if(e_otp==g_otp)
		{
			System.out.println("\nPayment processing.. ...!!!\nPlease wait");
			if(bal>0)
			{
				System.out.println("Your balance amount for payment is "+bal);
				System.out.println("Thank you for your transaction");
			}
			else if(bal<0)
				System.out.println("Wrong payment!!\nPayment unsuccessfull...");
			else
			{
				System.out.println("\nPayment successfull :-) !!!");
				System.out.println("Thank you for your transaction");
			}
		}
		else
		{
			System.out.println("Oops...\nWrong OTP");
			System.out.println("Kindly start your transaction from first");
			others();
		}
		System.out.println("Do you want to do another payment (yes/no) ?");
		ch=sc.next().charAt(0);
		}while(ch=='y'||ch=='Y');
	}
}