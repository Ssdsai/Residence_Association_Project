package residence;
import java.util.*;
class Node
{//node class
    int data,num;
    char pos;
    long phone;
    String name;
    Node next, prev;
    Node()
    {//default node with initial values
        next = null;
        prev = null;
        data = 0;
        num = 0;
        phone = 0L;
        pos = '\u0000';
        name = "";
    }
    Node(int d,int nu,String na,long ph,char po,Node n, Node p)
    {//parameterized node for initializing with new values
        data = d;
        num = nu;
        next = n;
        prev = p;
        name = na;
        phone = ph;
        pos = po;
    }
    void setLinkNext(Node n){next = n;}
    void setLinkPrev(Node p){prev = p;}    
    Node getLinkNext(){return next;}
    Node getLinkPrev(){return prev;}
    void setData1(int d,int nu,String na,long ph,char po){data = d;num = nu;name = na;phone = ph;pos = po;}
    //below methods are to return the values of that node
    int getData1(){return data;}
    String getData2(){return name;}
    int getData3() {return num;}
    long getData4() {return phone;}
    char getData5() {return pos;}
}
public class LinkedList
{
    Node start;
    Node end ;
    int size;
    public LinkedList()
    {
        start = null;
        end = null;
        size = 0;
    }
    public boolean isEmpty()
    {
        return start == null;
    }
    public int getSize()
    {
        return size;
    }
    public void insertAtEnd(int val1,int val3,String val2,long val4,char val5)
    {//insertion at end concept
        Node nptr = new Node(val1,val3,val2,val4,val5, null, null);        
        if (start == null)
        {
            nptr.setLinkNext(nptr);
            nptr.setLinkPrev(nptr);
            start = nptr;
            end = start;
        }
        else
        {
            nptr.setLinkPrev(end);
            end.setLinkNext(nptr);
            start.setLinkPrev(nptr);
            nptr.setLinkNext(start);
            end = nptr;    
        }
        size++;
    }
    public void display()
    {
        Node ptr = start;
        if (size == 0) 
        {
            System.out.print("\nNo residents registered yet\n");
            return;
        }
        while (ptr.getLinkNext() != start) 
        {
            System.out.print(ptr.getData1());
            System.out.print("\t"+ptr.getData2());
            System.out.print("\t"+ptr.getData3()+"\n");
            ptr = ptr.getLinkNext();
        }
        System.out.print(ptr.getData1());
        System.out.print("\t"+ptr.getData2());
        System.out.print("\t"+ptr.getData3()+"\n");
    }
    public Node search(int val)
    {
    	Node current = start;   
        boolean flag = false;   
        if(start == null)
            System.out.println("\nNo residents registered yet\n");  
        else 
        {  
        do{  
            if(current.data ==  val) 
            {  
                flag = true;
                break;  
            }  
            current = current.next;    
        }while(current != start);
        }
        return current;//returning the found node
    }
}