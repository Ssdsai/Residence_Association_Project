package residence;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
public class Manager extends Welcome
{//Admin Page
	String nm,dept;
	public static final Manager[] m = new Manager[20];
	Deque<Manager> staff = new ArrayDeque<Manager>();//defining Deque interface
	Manager()
	{
		nm="";
		dept="";
	}
	Manager(String nm,String dept)
	{
		this.nm = nm;
		this.dept = dept;
	}
	public void admin() throws Exception
	{
		int choice=0,ch=1,c=0;
		Scanner sc = new Scanner(System.in);
		String ad_id,ad_pass;
		System.out.println("\nLogin success!!!\n\n");
		System.out.println(". . ... .   .    ..");
		System.out.println(":.: :.. :   :   :  :");
		System.out.println(": : :.. :.. :..  ..");
		System.out.println("\nThis page is restricted only for the manager.");
		System.out.println("All important, official and secure data are stored, modified in this page.");
		System.out.println("Residents are not allowed to do anything");
		do {
		System.out.println("\n\t~~~\n\tOPTIONS\n\t~~~");
		System.out.println("\t1.Issues\n\t2.Password details\n\t3.Add staff details\n\t4.Display staff details\n");
		System.out.println("Which details do you wish to see (1-4)?");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:general();
			   break;
		case 2:password();
			   break;
		case 3:staff_enter();
			   break;
		case 4:staff_disp();
			   break;
		default:System.out.println("\nInvalid choice");
		}
		System.out.println("\nIf you want to go back to Admin page please enter 1");
		c = sc.nextInt();
		}while(c==1);
		System.out.println("\nTo go back to menu, please enter 0 button.");
	   	ch=sc.nextInt();
	   	if(ch==0)
	   		super.menu();
	}
	public void general()
	{
		Scanner sc = new Scanner(System.in);
		int ch=0;
		System.out.println("\n\t\tChatbox");
		System.out.println("\t------------------------\n");
		try {
		File reader = new File("D:\\Eclipse\\Residence Association\\Issues.txt");
        BufferedReader input = new BufferedReader(new FileReader(reader));
        String line;
        while ((line = input.readLine()) != null) {
            System.out.println(line);
        }
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	public void password()
	{
		int choice=0;
		char pos;
		Scanner sc = new Scanner(System.in);
		System.out.println("\nDetails of the passwords");
		System.out.println("The password for the owner is " +Welcome.passo);
		System.out.println("The password for the person staying for rent is " +Welcome.passr);
		System.out.println("The password for the person staying for lease is " +Welcome.passl);
		System.out.println("\nWhich password do you wish to change (1-3) ?");
		System.out.println("1.Owner\n2.rent\n3.Lease\n");
		choice = sc.nextInt();
		if(choice==1)
		{
			pos = 'O';
			System.out.println("Enter the new password");
			Welcome.passo = sc.next();
			Welcome pass = new Welcome(Welcome.passo,pos);
		}
		else if(choice==2)
		{
			pos = 'R';
			System.out.println("Enter the new paasword");
			Welcome.passr = sc.next();
			Welcome pass = new Welcome(Welcome.passr,pos);
		}
		else if(choice==3)
		{
			pos = 'L';
			System.out.println("Enter the new password");
			Welcome.passl = sc.next();
			Welcome pass = new Welcome(Welcome.passl,pos);
		}
		else
			System.out.println("Invalid choice");
	}
	public void staff_enter()
	{
		int ch=0,i=0;
		Scanner sc = new Scanner(System.in);
		do {
			try {
		System.out.println("\nAdd details of staff members of apartment");
		System.out.println("Enter the name of the staff member :");
		nm = sc.next();
		System.out.println("Enter the department for which he/she work");
		dept = sc.next();
		Manager.m[i] = new Manager(nm,dept);//array of objects
		staff.add(Manager.m[i]);//adding to Deque interface
		System.out.println("Do you have to add details of another staff member (For yes enter 1)?");
		ch=sc.nextInt();
		i++;
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}while(ch==1);
	}
	public void staff_disp()
	{
		if(Manager.m==null)
		{
			System.out.println("The details of staff members has not been added yet");
			System.out.println("PLease check once again");
		}
		else
		{
			System.out.println("NAME\tDEPARTMENT");
			System.out.println("~~~~~~~~~");
			for(Manager m:staff)
				System.out.println(m.nm+"\t"+m.dept);
		}
	}
}