package residence;
import java.io.*;
import java.io.File;
import java.io.FileInputStream;
import java.util.*;
public class ComplaintPage extends Welcome
{
	public void issues()
	{
		int choice=0,c = 0;
		char ch;
		String m_m[] = new String[100] ;
		Scanner sc = new Scanner(System.in);
		System.out.println("\nWelcome to Help Page of Residence association.");
		System.out.println("You can check for cell numbers for the services, use notice board");
		System.out.println("You can also put any complaints,suggestions or concerns to the manger");
		do {
		System.out.println("\n\t1.Contact details\n\t2.Raise an Issue\n\t3.Notice Board");
		System.out.println("\nSelect among the options from 1 - 3 :");
		choice = sc.nextInt();
		if(choice==1)
		{
			System.out.println("\n\tThe contact numbers are displayed for your reference");
			System.out.println("\tYou can contact them for any issues through your mobile phone\n\n");
			System.out.println("----------------------------------------------------------------------");
			System.out.println("The contact details of the apartment manager is \nManager - Ph:"+manager);
			System.out.println("The contact details of the apartment security is \nSecurity - Ph:"+security);
			System.out.println("The contact details of the Incharge head of Maids is \nMaid_incharge - Ph:"+maid_inch);
			System.out.println("The contact details of the Swimming pool cleaning men is \nSwimming pool - Ph:"+swim);
			System.out.println("The contact details of the Gym equiptment men is \nGym - Ph:"+gym);
			System.out.println("The contact details of the Lift and escalator service is \nLift - Ph:"+lift);
			System.out.println("The contact details of the Gardener is \nGardener - Ph:"+garden);
			System.out.println("----------------------------------------------------------------------");
		}
		else if(choice==2)
		{
			
			System.out.println("\nThis option provides you to put up any messages to the manager");
			System.out.println("\n\t\tChatbox");
			System.out.println("\t---------------------------\n");
			try {
			
			System.out.println("Enter the message to be put up to Manager : ");
			FileWriter output = new FileWriter("C:\\Users\\91734\\Desktop\\New folder\\Issues.txt",true);
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			output.write(input.readLine());
			output.close();
			//Thread.sleep(5000);
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
			System.out.println("\nThank you for using the chatbox option..!! ");
		}
		else if(choice==3)
		{
			try
			{
				File reader = new File("C:\\Users\\91734\\Desktop\\New folder\\Notice_Board.txt");
	            BufferedReader bufferedReader = new BufferedReader(new FileReader(reader));
	            String line;
	            while ((line = bufferedReader.readLine()) != null) {
	                System.out.println(line);
	            }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			System.out.println("\nDo you want to add any information on the notice board (yes/no) ?");
			ch=sc.next().charAt(0);
			if(ch=='y'||ch=='Y')
			{
				try {
				FileWriter output = new FileWriter("C:\\Users\\91734\\Desktop\\New folder\\Notice_Board.txt",true);
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("Enter the info to be put on notice board");
				output.write(br.readLine());//writing info to notice board
				output.close();
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				try
				{
					File reader = new File("C:\\Users\\91734\\Desktop\\New folder\\Notice_Board.txt");
		            BufferedReader bufferedReader = new BufferedReader(new FileReader(reader));
		            String line;
		            System.out.println("\nThe updated notice board is :\n");
		            while ((line = bufferedReader.readLine()) != null) {
		                System.out.println(line);
		            }//Displaying again notice board with adding the new info
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
			else
				System.out.println("\nThank you!!!");
		}
		System.out.println("\nIf you want to go back to Help page please enter 1");
		c = sc.nextInt();//Return to the same section
		}while(c==1);
	}
}